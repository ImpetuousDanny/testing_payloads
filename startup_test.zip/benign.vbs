Set fso = CreateObject(Scripting.FileSystemObject)
Set shell = CreateObject(WScript.Shell)

desktop = shell.ExpandEnvironmentStrings(%USERPROFILE%) & Desktopstartup_test_ran.txt
Set f = fso.CreateTextFile(desktop, True)
f.WriteLine Startup test executed at  & Now
f.Close

MsgBox Startup folder persistence test executed successfully., vbInformation + vbOKOnly, Purple Team Test