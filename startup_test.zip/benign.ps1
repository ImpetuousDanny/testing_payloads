Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show(
    "Startup folder persistence test executed successfully.",
    "Purple Team Test"
)